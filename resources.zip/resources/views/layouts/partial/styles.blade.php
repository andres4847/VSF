    {{ Html::style('css/bootstrap.css') }}
    {{ Html::style('css/bevolnuteer.css') }}
    {{ Html::style('css/animate.css') }}
    {{ Html::style('css/prettyPhoto.css') }}
    {{ Html::style('css/presets/preset1.css') }}
    {{ Html::style('plugins/font-awesome-4.7.0/css/font-awesome.min.css') }}