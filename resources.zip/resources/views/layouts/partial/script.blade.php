     {{ Html::script('js/jquery-1.11.1.min.js') }}
     {{ Html::script('js/bootstrap.min.js') }}
     {{ Html::script('js/plugins.js') }}
     {{ Html::script('js/bevolnuteer-custom.js') }}
     {{ Html::script('js/jquery.prettyPhoto.js') }}
     {{ Html::script('js/widgets.js') }}
     {{ Html::script('plugins/instafeed/instafeed.js') }}
     {{ Html::script('js/mpago.js') }}

 
